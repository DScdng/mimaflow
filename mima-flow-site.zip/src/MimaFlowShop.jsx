
import { useState } from 'react';

const products = [
  { id: 1, name: "Rose Bouquet", price: 25, image: "/flowers/rose.jpg" },
  { id: 2, name: "Wedding Arch", price: 120, image: "/decor/arch.jpg" },
  { id: 3, name: "Table Centerpiece", price: 45, image: "/decor/centerpiece.jpg" },
];

export default function MimaFlowShop() {
  const [cart, setCart] = useState([]);
  const [orderInfo, setOrderInfo] = useState({ name: '', address: '', note: '' });
  const [orderPlaced, setOrderPlaced] = useState(false);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const handleOrder = () => {
    if (!orderInfo.name || !orderInfo.address) return alert("Please fill in all required fields");
    setOrderPlaced(true);
    setCart([]);
  };

  return (
    <div style={{ maxWidth: 800, margin: 'auto', padding: 20 }}>
      <h1 style={{ fontSize: 36, textAlign: 'center' }}>MIMA flow</h1>

      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
        {products.map(product => (
          <div key={product.id} style={{ border: '1px solid #ddd', padding: 16, borderRadius: 10, width: 240 }}>
            <img src={product.image} alt={product.name} style={{ width: '100%', height: 160, objectFit: 'cover', borderRadius: 8 }} />
            <h2 style={{ fontSize: 20 }}>{product.name}</h2>
            <p>${product.price}</p>
            <button onClick={() => addToCart(product)}>Add to cart</button>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 40 }}>
        <h2>Your Cart</h2>
        {cart.length === 0 ? <p>No items in cart.</p> : (
          <ul>
            {cart.map((item, index) => (
              <li key={index} style={{ marginBottom: 8 }}>
                {item.name} - ${item.price}
                <button onClick={() => removeFromCart(item.id)} style={{ marginLeft: 8 }}>Remove</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {cart.length > 0 && !orderPlaced && (
        <div style={{ marginTop: 30 }}>
          <h2>Order Details</h2>
          <input placeholder="Your Name" value={orderInfo.name} onChange={e => setOrderInfo({ ...orderInfo, name: e.target.value })} style={{ display: 'block', marginBottom: 10, width: '100%' }} />
          <textarea placeholder="Delivery Address" value={orderInfo.address} onChange={e => setOrderInfo({ ...orderInfo, address: e.target.value })} style={{ display: 'block', marginBottom: 10, width: '100%' }} />
          <textarea placeholder="Additional Note (optional)" value={orderInfo.note} onChange={e => setOrderInfo({ ...orderInfo, note: e.target.value })} style={{ display: 'block', marginBottom: 10, width: '100%' }} />
          <button onClick={handleOrder}>Place Order</button>
        </div>
      )}

      {orderPlaced && (
        <div style={{ marginTop: 30, padding: 20, backgroundColor: '#e0ffe0', borderRadius: 10 }}>
          <h2>Thank you for your order!</h2>
          <p>We’ll be in touch shortly with delivery details. 🌸</p>
        </div>
      )}
    </div>
  );
}
