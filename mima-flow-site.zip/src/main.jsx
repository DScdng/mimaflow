import React from 'react'
import ReactDOM from 'react-dom/client'
import MimaFlowShop from './MimaFlowShop'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MimaFlowShop />
  </React.StrictMode>
)
