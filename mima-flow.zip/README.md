# MIMA flow

Flower and decoration webshop built with React.